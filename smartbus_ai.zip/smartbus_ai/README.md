# SmartBus AI - Intelligent Bus Arrival Time Prediction System
Flask + SQLite + Chart.js. Palette: orange, white, dark green, light grey (no blue).

## Run
```
pip install -r requirements.txt
python app.py            # open http://127.0.0.1:5000
```
## Train a model (optional)
```
python ml/train.py       # Random Forest -> ml/eta_model.joblib (auto-loaded)
python ml/train.py --gru # also trains a GRU (pip install tensorflow)
```
## Honesty notes
- Bus positions are **simulated demo data**; replace `bus_state()` in app.py with a real GPS feed.
- Without `ml/eta_model.joblib` the app uses a **rule-based baseline** (labelled in the UI). The GRU is trained by `train.py --gru` but is not wired into predictions yet; blend it in `ml/predictor.py`.
- The Random Forest trained by default uses synthetic data; swap `make_data()` for rows from the `trips` table.

## Structure
app.py (API + SQLite) | ml/predictor.py, ml/train.py | templates/index.html | static/css, static/js | data/smartbus.db (auto-created)
Endpoints: /api/meta, /api/track, /api/predict, /api/traffic-effect, /api/history, /api/analytics, /api/contact
